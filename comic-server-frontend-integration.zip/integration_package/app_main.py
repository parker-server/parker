from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from fastapi.exceptions import HTTPException
import logging
from pathlib import Path

# Import your API routers
from app.api import comics, libraries, reader, progress, collections, reading_lists

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Comic Server",
    description="A modern comic book server with web interface",
    version="1.0.0"
)

# CORS middleware (adjust origins as needed)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify your domains
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Get directories relative to this file
# app/main.py -> app/ -> project/
BASE_DIR = Path(__file__).resolve().parent.parent

# Mount static files from project root
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")

# Setup templates from app/templates/
templates = Jinja2Templates(directory=str(BASE_DIR / "app" / "templates"))

# Global exception handler
@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    if "text/html" in request.headers.get("accept", ""):
        return templates.TemplateResponse(
            "error.html",
            {"request": request, "status_code": exc.status_code, "detail": exc.detail},
            status_code=exc.status_code
        )
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": exc.detail}
    )

@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unexpected error: {exc}", exc_info=True)
    if "text/html" in request.headers.get("accept", ""):
        return templates.TemplateResponse(
            "error.html",
            {"request": request, "status_code": 500, "detail": "Internal server error"},
            status_code=500
        )
    return JSONResponse(
        status_code=500,
        content={"error": "Internal server error"}
    )

# Include API routers
app.include_router(comics.router, prefix="/api/comics", tags=["comics"])
app.include_router(libraries.router, prefix="/api/libraries", tags=["libraries"])
app.include_router(reader.router, prefix="/api/reader", tags=["reader"])
app.include_router(progress.router, prefix="/api/progress", tags=["progress"])
app.include_router(collections.router, prefix="/api/collections", tags=["collections"])
app.include_router(reading_lists.router, prefix="/api/reading-lists", tags=["reading_lists"])


# Health check endpoint
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "comic-server"}


@app.on_event("startup")
async def startup_event():
    """Run on application startup"""
    logger.info("Comic Server starting up...")
    logger.info("Frontend available at http://localhost:8000")
    logger.info("API docs available at http://localhost:8000/docs")


@app.on_event("shutdown")
async def shutdown_event():
    """Run on application shutdown"""
    logger.info("Comic Server shutting down...")


# Frontend routes
@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    """Home page - Library browser"""
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/library/{library_id}", response_class=HTMLResponse)
async def library_view(request: Request, library_id: int):
    """View a specific library"""
    return templates.TemplateResponse("library.html", {
        "request": request,
        "library_id": library_id
    })


@app.get("/reader/{comic_id}", response_class=HTMLResponse)
async def reader(request: Request, comic_id: int):
    """Comic reader"""
    return templates.TemplateResponse("reader.html", {
        "request": request,
        "comic_id": comic_id
    })


@app.get("/search", response_class=HTMLResponse)
async def search(request: Request):
    """Search page"""
    return templates.TemplateResponse("search.html", {"request": request})


@app.get("/collections", response_class=HTMLResponse)
async def collections_view(request: Request):
    """Collections page"""
    return templates.TemplateResponse("collections.html", {"request": request})


@app.get("/reading-lists", response_class=HTMLResponse)
async def reading_lists_view(request: Request):
    """Reading lists page"""
    return templates.TemplateResponse("reading_lists.html", {"request": request})


@app.get("/continue-reading", response_class=HTMLResponse)
async def continue_reading(request: Request):
    """Continue reading page"""
    return templates.TemplateResponse("continue_reading.html", {"request": request})
